#!/bin/bash

# ANSI color code for dark green
DARK_GREEN='\033[0;32m'
# ANSI color code for red
RED='\033[0;31m'
# ANSI color code to reset to default text color
RESET='\033[0m'

# Function to display progress bar
display_progress_bar() {
    local progress=0
    local bar_length=50
    local sleep_duration=0.035  # 3.5 seconds / 100 increments = 0.035 seconds per increment

    while [ $progress -le 100 ]; do
        # Calculate the number of filled and empty slots in the bar
        filled=$(($progress * $bar_length / 100))
        empty=$(($bar_length - $filled))

        # Create the progress bar string
        bar=$(printf "%${filled}s" | tr ' ' '#')
        bar+=$(printf "%${empty}s")

        # Print the progress bar
        echo -ne "\r${RED}[${bar}] ${progress}%${RESET}"

        # Increment the progress
        progress=$((progress + 1))

        # Sleep for the specified duration
        sleep $sleep_duration
    done

    # Print a newline at the end
    echo
}

# Function to colorize output
colorize_output() {
    while IFS= read -r line; do
        echo -e "${DARK_GREEN}${line}${RESET}"
    done
}

# Run commands and colorize their output
echo -e "${DARK_GREEN}Clearing package cache...${RESET}"
sudo pacman -Sc --noconfirm | colorize_output

echo -e "${DARK_GREEN}Removing cache directories...${RESET}"
sudo rm -rf /var/cache/ | colorize_output

echo -e "${DARK_GREEN}Clearing temporary files...${RESET}"
sudo rm -rf /tmp | colorize_output

echo -e "${DARK_GREEN}Clearing root user cache...${RESET}"
sudo rm -rf /root/.cache/ | colorize_output

echo -e "${DARK_GREEN}Clearing user trash...${RESET}"
sudo rm -rf /home/lancaster/.local/share/Trash | colorize_output

echo -e "${DARK_GREEN}Clearing root user trash...${RESET}"
sudo rm -rf /root/.local/share/Trash/ | colorize_output

# Display the progress bar after commands
display_progress_bar
