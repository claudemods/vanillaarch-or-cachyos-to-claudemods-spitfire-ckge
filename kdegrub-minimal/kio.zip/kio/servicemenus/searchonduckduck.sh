#!/bin/bash

# Prompt the user for a search query using kdialog
QUERY=$(kdialog --inputbox "Search On DuckDuckGo")

# Check if the query is not empty
if [ -n "$QUERY" ]; then
    # Open the default web browser with the DuckDuckGo search URL
    xdg-open "https://duckduckgo.com/?q=${QUERY}"
fi
