#!/bin/bash
su && konsole
