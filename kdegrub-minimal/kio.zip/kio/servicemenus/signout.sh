#!/bin/bash
echo -e "\033[38;2;0;255;255mSigning Out Now in 1.5 Seconds\\e[0m"
play /home/$USER/.local/share/kio/servicemenus/shutdown.wav > /dev/null 2>&1
qdbus6 org.kde.KWin /Session org.kde.KWin.Session.quit
