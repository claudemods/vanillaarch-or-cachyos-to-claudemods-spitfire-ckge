#!/bin/bash
echo -e "\033[38;2;0;255;255mRebooting Now In 1.5 Seconds\\e[0m"
play /home/$USER/.local/share/kio/servicemenus/shutdown.wav > /dev/null 2>&1
reboot
