#!/bin/bash

# Prompt the user for a search query using kdialog
QUERY=$(kdialog --inputbox "Search On StartPage")

# Check if the query is not empty
if [ -n "$QUERY" ]; then
    # Open the default web browser with the StartPage search URL
    xdg-open "https://www.startpage.com/do/search?q=${QUERY}"
fi
