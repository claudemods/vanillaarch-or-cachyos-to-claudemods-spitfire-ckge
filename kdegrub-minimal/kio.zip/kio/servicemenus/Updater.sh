#!/bin/bash

# ANSI color code for dark green
Teal='\033[38;2;0;255;255m'
# ANSI color code for red
RED='\033[0;31m'
# ANSI color code to reset to default text color
RESET='\033[0m'

echo -e "${Teal}Checking for system and application updates${RESET}"

# Function to colorize output
colorize_output() {
    while IFS= read -r line; do
        echo -e "${Teal}${line}${RESET}"
    done
}

# Function to display progress bar
display_progress_bar() {
    local progress=0
    local bar_length=50
    local sleep_duration=0.035  # 3.5 seconds / 100 increments = 0.035 seconds per increment

    while [ $progress -le 100 ]; do
        # Calculate the number of filled and empty slots in the bar
        filled=$(($progress * $bar_length / 100))
        empty=$(($bar_length - $filled))

        # Create the progress bar string
        bar=$(printf "%${filled}s" | tr ' ' '#')
        bar+=$(printf "%${empty}s")

        # Print the progress bar
        echo -ne "\r${RED}[${bar}] ${progress}%${RESET}"

        # Increment the progress
        progress=$((progress + 1))

        # Sleep for the specified duration
        sleep $sleep_duration
    done

    # Print a newline at the end
    echo
}

# Run commands and colorize their output
sudo pacman -Sy --noconfirm | colorize_output
sudo pacman -Syu --noconfirm | colorize_output

# Prompt user to clear pacman cache
echo -e "${Teal}Do you want to clear the pacman cache? (y or n)${RESET}"
read -r response

if [[ $response =~ ^[Yy]$ ]]; then
    echo -e "${Teal}Clearing pacman cache...${RESET}"
    sudo pacman -Sc --noconfirm | colorize_output
    echo -e "${RED}Clearing cache...${RESET}"
    display_progress_bar
else
    echo -e "${Teal}Pacman cache will not be cleared.${RESET}"
fi
