#!/bin/bash

# Prompt the user for a search query using kdialog
QUERY=$(kdialog --inputbox "Search On Google")

# Check if the query is not empty
if [ -n "$QUERY" ]; then
    # Open the default web browser with the Google search URL
    xdg-open "https://www.google.com/search?q=${QUERY}"
fi
